import img3 from "../assets/images (3).jpg"
import img1 from "../assets/istockphoto-1296273988-612x612.jpg"
import img2 from "../assets/SPAGHETTI-POMODORO-CON-CAMARONES-WEB-MONTICELLO-1200x675.jpg"
import img4 from "../assets/images (4).jpg"

export const INITIAL_CONTACTS = [
    { id: 1, Name: "Italian-style tomato salad", img: img1, minutes: 14, state: false },
    { id: 2, Name: "Spaghetti with vegetables and phrimp", img: img2, minutes: 15, state: false },
    { id: 3, Name: "Lotus delight salad", minutes: 20, img: img3, state: false },
    { id: 4, Name: "Snack cakes", minutes: 21, img: img4, state: false },
];


