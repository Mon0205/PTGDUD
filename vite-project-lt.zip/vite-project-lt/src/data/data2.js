import img1 from "../assets/fisk82.jpg"
import img2 from "../assets/istockphoto-1296273988-612x612.jpg"
import img3 from "../assets/download (1).jpg"
import img4 from "../assets/download.jpg"
import img5 from "../assets/images (5).jpg"
import img6 from "../assets/images (6).jpg"
import img7 from "../assets/images (7).jpg"
import img8 from "../assets/images (8).jpg"
export const INITIAL_CONTACTS2 = [
    { id: 1, Name: "Salad with cabbage and shrimp", img: img1, minutes: 32, state: false },
    { id: 2, Name: "Salad of cove beans, phrimp and potatoes", img: img2, minutes: 20, state: false },
    { id: 3, Name: "Sunny-side up fried egges", minutes: 15, img: img3, state: false },
    { id: 4, Name: "Lotus delight salad", minutes: 20, img: img4, state: false },
];
export const INITIAL_CONTACTS4 = [
    { id: 1, Name: "Italian-style tomato salad", img: img1, minutes: 14, state: false },
    { id: 2, Name: "Spaghetti with vegetables and phrimp", img: img2, minutes: 15, state: false },
    { id: 3, Name: "Lotus delight salad", minutes: 20, img: img3, state: false },
    { id: 4, Name: "Snack cakes", minutes: 21, img: img4, state: false },
    { id: 5, Name: "Salad with cabbage and shrimp", img: img5, minutes: 32, state: false },
    { id: 6, Name: "Salad of cove beans, phrimp and potatoes", img: img6, minutes: 20, state: false },
    { id: 7, Name: "Sunny-side up fried egges", minutes: 15, img: img7, state: false },
    { id: 8, Name: "Lotus delight salad", minutes: 20, img: img8, state: false },
    { id: 9, Name: "Lotus delight salad", minutes: 20, img: img8, state: false },
];

